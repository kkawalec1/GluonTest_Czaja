import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.security.cert.PolicyNode;

public class AplikacjaController {
    @FXML
    private TextField imie;
    @FXML
    private Button Zatwierdz;
    @FXML
    private TextField nazwisko;
    @FXML
    private TextField email;
    @FXML
    private TextField haslo;
    @FXML
    private TextField phaslo;
    @FXML
    private Label komunikat;

}